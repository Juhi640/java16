package com.mindtree.universitymanagementapplication.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import com.mindtree.universitymanagementapplication.entity.College_University;
import com.mindtree.universitymanagementapplication.entity.University;
import com.mindtree.universitymanagementapplication.exception.InvalidRatingException;
import com.mindtree.universitymanagementapplication.exception.NoSuchUniversityPresentException;
import com.mindtree.universitymanagementapplication.exception.ServiceException;
import com.mindtree.universitymanagementapplication.service.serviceimpl.UniversityCollegeServiceImpl;

public class UniversityApp {
	
	static Scanner obj=new Scanner(System.in);

	 static UniversityCollegeServiceImpl obj2=new UniversityCollegeServiceImpl();
	 
	public static void main(String[] args)  {
	
		String str;
		do {
		System.out.println("1. for registering to university\n 2. for getting all university \n 3. for getting all colleges in a particular university\n 4. for getting all colleges by rating");
		System.out.println("enter choice");
		int ch=obj.nextInt();
		obj.nextLine();
		switch(ch) {
		
		case 1:	Set<University> u1=new HashSet<>();
				University u=new University();
				System.out.println("enter university id");
				int universityid=obj.nextInt();
				obj.nextLine();
				System.out.println("enter university name");
				String universityname=obj.nextLine();
				boolean result=false;
					try {
						result=obj2.DuplicateUniversityName(universityname);
						
					}catch (ServiceException e) {
						System.out.println(e.getMessage());
						} 
				if(result==true)	{
				u=new University(universityid,universityname);
				boolean isInserted=true;
				isInserted=obj2.RegisterToUniversity(u);
				System.out.println("successfully inserted");
					u1=obj2.GetAllUniversity();
				for(University u2:u1) {
					System.out.println(u2.getUniversityId());
					System.out.println(u2.getUniversityName());
				}
				}
				break;
				
		case 2:Set<University>u11=new HashSet<>();
			u11=obj2.GetAllUniversity();
			for(University u2:u11) {
			System.out.println(u2.getUniversityId());
			System.out.println(u2.getUniversityName());
			}
			//Set<College_University> cu=new HashSet<>();
			College_University cu1=new College_University();
			System.out.println("enter university id");
			int universityid1=obj.nextInt();
			obj.nextLine();
			System.out.println("enter collegename");
			String  collegename=obj.nextLine();
			System.out.println("enter rating");
			int rating=obj.nextInt();
			boolean result1=false;
				try {
					result1=obj2.InvalidRating(rating);
					
			}catch (ServiceException e) {
				System.out.println(e.getMessage());
				}
			if(result1==true)	{
			cu1=new College_University(universityid1,collegename,rating);
			boolean isInserted1=true;
			isInserted1=obj2.RegisterToCollege(cu1);
			System.out.println("successfully inserted");
			//cu.add(cu1);
			Set<College_University>cu11=new HashSet<>();
			cu11=obj2.GetAllDetails();
			for(College_University cc:cu11) {
				System.out.println(cc.getCollegeId());
				System.out.println(cc.getCollegeName());
				System.out.println(cc.getRating());
				System.out.println(cc.getUniversityId());
				System.out.println(cc.getUniversityName());
			}
			}
			break;
			
		case 3:Set<College_University> cu3=new HashSet<>();
				System.out.println("enter university id");
				int universityid11=obj.nextInt();
				boolean result11=false;
					try {
						result11=obj2.NoSuchUniversityPresent(universityid11);

				}catch (ServiceException e) {
					System.out.println(e.getMessage());
					}
				if(result11==true)	{
				cu3=obj2.GetAllColleges1(universityid11);
				for(College_University cc:cu3) {
					System.out.println(cc.getCollegeId());
					System.out.println(cc.getCollegeName());
					System.out.println(cc.getRating());
					System.out.println(cc.getUniversityId());
					System.out.println(cc.getUniversityName());
				}
				ArrayList<College_University> cu4=new ArrayList<>(cu3);
				Collections.sort(cu4,new Comparator<College_University>() {
					public int compare(College_University o1, College_University o2) {
					if(o1.getRating()<o2.getRating())
						return 1;
					else
						return -1;
					}	
				});
				System.out.println("sorted list is:");
				for(College_University cu5:cu4) {
					System.out.println(cu5.getCollegeId());
					System.out.println(cu5.getCollegeName());
					System.out.println(cu5.getRating());
					System.out.println(cu5.getUniversityId());
					System.out.println(cu5.getUniversityName());
					
				}
				}
				break;
				
		case 4:Set<College_University>cu5=new HashSet<>();
				System.out.println("enter rating");
				int rating1=obj.nextInt();
				boolean result111=false;
					try {
						result111=obj2.InvalidRating(rating1);
						
				}catch (ServiceException e) {
					System.out.println(e.getMessage());
					}
				if(result111==true)	{
				cu5=obj2.GetAllCollegesByRating1(rating1);
				for(College_University cu6:cu5) {
					System.out.println(cu6.getCollegeId());
					System.out.println(cu6.getCollegeName());
					System.out.println(cu6.getRating());
					System.out.println(cu6.getUniversityId());
					System.out.println(cu6.getUniversityName());
					
				}
				}
				break;
				
	
		default:System.out.println("wrong input");
				break;
				}
		
		System.out.println("whether you want to continue(yes/no)");
		str=obj.next();

	}while(str.equals("yes"));
	}
}
