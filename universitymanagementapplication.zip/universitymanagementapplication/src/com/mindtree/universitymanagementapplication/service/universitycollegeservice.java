package com.mindtree.universitymanagementapplication.service;

import java.util.Set;

import com.mindtree.universitymanagementapplication.entity.College_University;
import com.mindtree.universitymanagementapplication.entity.University;
import com.mindtree.universitymanagementapplication.exception.ServiceException;

public interface universitycollegeservice {
	
	public boolean RegisterToUniversity(University u);
	
	Set<University> GetAllUniversity()throws ServiceException;
	
	boolean DuplicateUniversityName(String universityname1) throws ServiceException ;
	
	public boolean NoSuchUniversityPresent(int universityid1) throws ServiceException;
	
	boolean RegisterToCollege(College_University cu);
	
	Set<College_University> GetAllDetails();
	
	boolean InvalidRating(int rating)throws ServiceException;
	
	public Set<College_University> GetAllColleges1(int universityid1);
	
	public Set<College_University> GetAllCollegesByRating1(int rating1);

}
