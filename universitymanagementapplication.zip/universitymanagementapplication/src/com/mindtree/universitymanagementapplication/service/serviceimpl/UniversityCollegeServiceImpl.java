package com.mindtree.universitymanagementapplication.service.serviceimpl;

import java.util.HashSet;
import java.util.Set;

import com.mindtree.universitymanagementapplication.dao.daoimpl.UniversityCollegeDaoImpl;
import com.mindtree.universitymanagementapplication.entity.College_University;
import com.mindtree.universitymanagementapplication.entity.University;
import com.mindtree.universitymanagementapplication.exception.DuplicateUniversityNameException;
import com.mindtree.universitymanagementapplication.exception.InvalidRatingException;
import com.mindtree.universitymanagementapplication.exception.NoSuchUniversityPresentException;
import com.mindtree.universitymanagementapplication.exception.ServiceException;
import com.mindtree.universitymanagementapplication.service.universitycollegeservice;

public class UniversityCollegeServiceImpl implements universitycollegeservice {

	UniversityCollegeDaoImpl obj1 = new UniversityCollegeDaoImpl();

	public boolean RegisterToUniversity(University u) {

		boolean isInserted = true;
		isInserted = obj1.RegisterToUniversity(u);
		return isInserted;

	}

	public Set<University> GetAllUniversity() {
		Set<University> u = new HashSet<>();
		u = obj1.GetAllUniversity();
		return u;
	}

	public boolean DuplicateUniversityName(String universityname1) throws ServiceException {

		boolean result = true;
		Set<University> u = new HashSet<>();
		try {
			u = obj1.GetAllUniversity();
			for (University u1 : u) {
				if ((u1.getUniversityName().equals(universityname1))) {
					result = false;
					throw new DuplicateUniversityNameException("duplicate university name");
				}
			}
		} catch (DuplicateUniversityNameException e) {
			throw new ServiceException(e);
		}
		return result;

	}

	public boolean InvalidRating(int rating) throws ServiceException {

		boolean result = true;
		try {
			if (rating < 0 || rating > 10) {
				result = false;
				throw new InvalidRatingException("rating is invalid");
			}
		} catch (InvalidRatingException e) {
			throw new ServiceException(e);
		}
		return result;

	}

	public boolean NoSuchUniversityPresent(int universityid1) throws ServiceException {

		boolean result = true;
		Set<College_University> u = new HashSet<>();
		try {
			u = obj1.GetAllColleges(universityid1);
			for (College_University u1 : u) {
				if (u1.getUniversityId() != universityid1) {
					result = false;
					throw new NoSuchUniversityPresentException("university id is not present");
				}
			}
		} catch (NoSuchUniversityPresentException e) {
			throw new ServiceException(e);
		}
		return result;

	}

	public boolean RegisterToCollege(College_University cu) {
		boolean isInserted = true;
		isInserted = obj1.RegisterToCollege(cu);
		return isInserted;
	}

	public Set<College_University> GetAllDetails() {
		Set<College_University> cu = new HashSet<>();
		cu = obj1.GetAllDetails();
		return cu;
	}

	public Set<College_University> GetAllColleges1(int universityid1) {
		Set<College_University> cu = new HashSet<>();
		cu = obj1.GetAllColleges(universityid1);
		return cu;

	}

	public Set<College_University> GetAllCollegesByRating1(int rating1) {
		Set<College_University> cu = new HashSet<>();
		cu = obj1.GetAllCollegesByRating(rating1);
		return cu;
	}
}
