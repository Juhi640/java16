package com.mindtree.universitymanagementapplication.entity;

public class College {
	
	private int collegeId;
	private String collegeName;
	private int rating;
	
	public College() {
		super();
	}

	public College(int collegeId, String collegeName, int rating) {
		super();
		this.collegeId = collegeId;
		this.collegeName = collegeName;
		this.rating = rating;
	}

	public int getCollegeId() {
		return collegeId;
	}

	public void setCollegeId(int collegeId) {
		this.collegeId = collegeId;
	}

	public String getCollegeName() {
		return collegeName;
	}

	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}
	
}
