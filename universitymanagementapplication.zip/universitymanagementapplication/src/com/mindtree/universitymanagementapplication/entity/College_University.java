package com.mindtree.universitymanagementapplication.entity;

public class College_University {
	
	private int collegeId;
	private String collegeName;
	private int rating;
	private int universityId;
	private String universityName;
	
	
	public College_University() {
		super();
	}


	public College_University(int collegeId, String collegeName, int rating, int universityId,
			String universityName) {
		super();
		this.collegeId = collegeId;
		this.collegeName = collegeName;
		this.rating = rating;
		this.universityId = universityId;
		this.universityName = universityName;
	}
	
	public College_University(int universityId2,String collegeName2,int rating2) {
		super();
		this.universityId = universityId2;
		this.collegeName = collegeName2;
		this.rating = rating2;
		
	}

	

	public int getCollegeId() {
		return collegeId;
	}


	public void setCollegeId(int collegeId) {
		this.collegeId = collegeId;
	}


	public String getCollegeName() {
		return collegeName;
	}


	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}


	public int getRating() {
		return rating;
	}


	public void setRating(int rating) {
		this.rating = rating;
	}


	public int getUniversityId() {
		return universityId;
	}


	public void setUniversityId(int universityId) {
		this.universityId = universityId;
	}


	public String getUniversityName() {
		return universityName;
	}


	public void setUniversityName(String universityName) {
		this.universityName = universityName;
	}
	
	

}
