package com.mindtree.universitymanagementapplication.dao.daoimpl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedHashSet;
import java.util.Set;

import com.mindtree.universitymanagementapplication.dao.universitycollegedao;
import com.mindtree.universitymanagementapplication.entity.College_University;
import com.mindtree.universitymanagementapplication.entity.University;
import com.mindtree.universitymanagementapplication.utility.DBUtility;

public class UniversityCollegeDaoImpl implements universitycollegedao {

	public boolean RegisterToUniversity(University u) {

		boolean isinserted = true;

		Connection con = DBUtility.getConnection();

		// String query = "";

		// query = "insert into university values(" + u.getUniversityId() + ",'" +
		// u.getUniversityName() + "');";

		CallableStatement cs = null;
		try {
			cs = con.prepareCall("{call inserttable(?,?)}");
			cs.setInt(1, u.getUniversityId());
			cs.setString(2, u.getUniversityName());
			cs.executeUpdate();

		} catch (SQLException e) {

			e.printStackTrace();
		}

		finally {
			try {
				cs.close();
				con.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		return isinserted;
	}

	public Set<University> GetAllUniversity() {
		Connection con = DBUtility.getConnection();
		Set<University> result = new LinkedHashSet<>();

		String query1 = "call getUniversity()";

		CallableStatement cs = null;
		ResultSet rs = null;
		try {
			cs = con.prepareCall(query1);
			rs = cs.executeQuery();

			while (rs.next()) {
				int universityid = rs.getInt("universityid");
				String universityname = rs.getString("universityname");

				University u = new University(universityid, universityname);
				result.add(u);
			}

		} catch (SQLException e) {
			e.printStackTrace();

		}

		finally {
			try {
				rs.close();
				cs.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();

			}
		}
		return result;
	}

	public boolean RegisterToCollege(College_University cu) {

		boolean isinserted = true;

		Connection con = DBUtility.getConnection();

		String query = "";

		query = "insert into college_university1 values(default,'" + cu.getCollegeName() + "'," + cu.getRating() + ","
				+ cu.getUniversityId() + ");";

		Statement stmt = null;
		try {
			stmt = con.createStatement();
			stmt.executeUpdate(query);

		} catch (SQLException e) {

			e.printStackTrace();
		}

		finally {
			try {
				stmt.close();
				con.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		return isinserted;
	}

	public Set<College_University> GetAllDetails() {
		Connection con = DBUtility.getConnection();
		Set<College_University> result = new LinkedHashSet<>();

		String query1 = " select collegeid,collegename,rating,cu.universityid,universityname from college_university1 cu join university u on u.universityid=cu.universityid;";

		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery(query1);

			while (rs.next()) {
				int collegeid = rs.getInt("collegeid");
				String collegename = rs.getString("collegename");
				int rating = rs.getInt("rating");
				int universityid = rs.getInt("universityid");
				String universityname = rs.getString("universityname");

				College_University cu = new College_University(collegeid, collegename, rating, universityid,
						universityname);
				result.add(cu);
			}

		} catch (SQLException e) {
			e.printStackTrace();

		}

		finally {
			try {
				rs.close();
				stmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();

			}
		}
		return result;
	}

	public Set<College_University> GetAllColleges(int universityid1) {
		Connection con = DBUtility.getConnection();
		Set<College_University> result = new LinkedHashSet<>();

		// String query1 = "select
		// collegeid,collegename,rating,cu.universityid,universityname from
		// college_university1 cu join university u on u.universityid=cu.universityid
		// where cu.universityid= "+universityid1+";";
		CallableStatement cs = null;
		ResultSet rs = null;
		try {

			cs = con.prepareCall("{call getdetails(?)}");
			cs.setInt(1, universityid1);
			rs = cs.executeQuery();

			while (rs.next()) {
				int collegeid = rs.getInt("collegeid");
				String collegename = rs.getString("collegename");
				int rating = rs.getInt("rating");
				int universityid = rs.getInt("universityid");
				String universityname = rs.getString("universityname");

				College_University cu = new College_University(collegeid, collegename, rating, universityid,
						universityname);
				result.add(cu);
			}

		} catch (SQLException e) {
			e.printStackTrace();

		}

		finally {
			try {
				rs.close();
				cs.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();

			}
		}
		return result;
	}

	public Set<College_University> GetAllCollegesByRating(int rating1) {

		Set<College_University> result = new LinkedHashSet<>();

		String query1 = "select collegeid,collegename,rating,cu.universityid,universityname from college_university1 cu join university u on u.universityid=cu.universityid where rating > "
				+ rating1 + ";";

		try (Connection con = DBUtility.getConnection(); 
				Statement stmt = con.createStatement()) {

			try (ResultSet rs = stmt.executeQuery(query1)) {

				while (rs.next()) {
					int collegeid = rs.getInt("collegeid");
					String collegename = rs.getString("collegename");
					int rating = rs.getInt("rating");
					int universityid = rs.getInt("universityid");
					String universityname = rs.getString("universityname");

					College_University cu = new College_University(collegeid, collegename, rating, universityid,
							universityname);
					result.add(cu);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();

		}

		return result;
	}

}
