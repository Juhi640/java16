package com.mindtree.universitymanagementapplication.dao;

import java.util.Set;

import com.mindtree.universitymanagementapplication.entity.College_University;
import com.mindtree.universitymanagementapplication.entity.University;
import com.mindtree.universitymanagementapplication.exception.DaoException;

public interface universitycollegedao {
	
	public boolean RegisterToUniversity(University u);
	
	Set<University> GetAllUniversity() throws DaoException;
	
	boolean RegisterToCollege(College_University cu);
	
	Set<College_University> GetAllDetails();
	
	public Set<College_University> GetAllColleges(int universityid1);
	
	public Set<College_University> GetAllCollegesByRating(int rating1);
	

}
