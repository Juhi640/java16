package client;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import entity.Person;
import exception.InvalidPhoneException;
import serviceimpl.ServiceImplement;

public class PersonApp {

	static ServiceImplement obj1 = new ServiceImplement();
	static Scanner obj = new Scanner(System.in);

	public static Set<Person> createTable() {
		Set<Person> p = new HashSet<>();
		Person person = new Person();
		System.out.println("enter id");
		int id = obj.nextInt();
		obj.nextLine();
		System.out.println("enter name");
		String name = obj.nextLine();
		System.out.println("enter phone number");
		String phonenumber = obj.nextLine();
		boolean result=true;
		try {
			 result = obj1.validPhoneNumber(phonenumber);
		} catch (InvalidPhoneException e) {
			System.out.println(e.getMessage());
		}
		if(result==false) {
		person = new Person(id, name, phonenumber);
		obj1.InsertPersonDetailsToDB(person);
		p.add(person);
		return p;
		}
		else
		return null;
	}

	public static void main(String[] args) {
		String str;

		do {
			System.out.println(
					"enter 1. for inserting values to database\n 2. for retrieving datas from database\n 3. for exit");
			System.out.println("enter choice");
			int choice = obj.nextInt();
			switch (choice) {

			case 1:
				Set<Person> p = createTable();
				break;

			case 2:
				Set<Person> p1 = obj1.retrieveDataFromDB();
				System.out.println("Data Retrived");
				System.out.println(p1);
				break;

			case 3:
				break;

			default:
				System.out.println("wrong input");
				break;

			}
			System.out.println("whether you want to continue (yes/no)");
			str = obj.next();
		} while (str.equals("yes"));
	}
}
