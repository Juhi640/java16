package daoservice;

import java.util.Set;

import entity.Person;

public interface DaoService {

	public Person InsertPersonDetailsToDB(Person persons);

	public Set<Person> retrieveDataFromDB();

}
