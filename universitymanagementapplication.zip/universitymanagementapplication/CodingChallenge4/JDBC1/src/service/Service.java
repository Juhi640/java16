package service;

import java.util.Set;

import entity.Person;
import exception.InvalidPhoneException;

public interface Service {

	public Person InsertPersonDetailsToDB(Person person);

	public boolean validPhoneNumber(String phonenumber) throws InvalidPhoneException;

	public Set<Person> retrieveDataFromDB();

}
