package daoimpl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Set;

import daoservice.DaoService;
import entity.Person;
import exception.DaoException;
import exception.InvalidPhoneException;
import utility.DBUtility;

public class DaoImplement implements DaoService {

	public Person InsertPersonDetailsToDB(Person person) {
		Connection con = DBUtility.getConnection();

		String query = "";

		query = "insert into  values(" + person.getId() + ",'" + person.getName() + "','"
				+ person.getPhonenumber() + "');";

		Statement stmt = null;
		try {
			stmt = con.createStatement();
			stmt.executeUpdate(query);

		} catch (SQLException e) {

			e.printStackTrace();
		}

		finally {
			try {
				stmt.close();
				con.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		return person;
	}

	public Set<Person> retrieveDataFromDB() {

		Connection con = DBUtility.getConnection();
		Set<Person> result = new HashSet<>();

		String query1 = "select * from person";

		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery(query1);

			while (rs.next()) {
				int id = rs.getInt("id");
				String name = rs.getString("name");
				String phonenumber = rs.getString("phonenumber");
				Person p1 = new Person(id, name, phonenumber);
				result.add(p1);
			}

		} catch (SQLException e) {
			e.printStackTrace();

		}

		finally {
			try {
				rs.close();
				stmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();

			}
		}
		return result;
	}

}
