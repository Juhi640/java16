package utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtility {

	static final String url = "jdbc:mysql://localhost:3306/juhi";
	static final String user = "root";
	static final String password = "Welcome123";

	public static Connection getConnection() {
		Connection con = null;

		try {
			con = DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return con;
	}
}
