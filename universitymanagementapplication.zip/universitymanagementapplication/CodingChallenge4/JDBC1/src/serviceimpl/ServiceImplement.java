package serviceimpl;

import java.util.Set;

import daoimpl.DaoImplement;
import entity.Person;
import exception.InvalidPhoneException;
import service.Service;

public class ServiceImplement implements Service {
	DaoImplement obj2 = new DaoImplement();

	public Person InsertPersonDetailsToDB(Person person) {

		person = obj2.InsertPersonDetailsToDB(person);
		return person;

	}

	public Set<Person> retrieveDataFromDB() {
		Set<Person> ptable;
		ptable = obj2.retrieveDataFromDB();
		return ptable;
	}

	public boolean validPhoneNumber(String phonenumber) throws InvalidPhoneException {
		boolean result = false;
		if (phonenumber.length() != 10)
		{
			result=true;
			throw new InvalidPhoneException("phone number is invalid");	
		}
		return result;

	}
}
