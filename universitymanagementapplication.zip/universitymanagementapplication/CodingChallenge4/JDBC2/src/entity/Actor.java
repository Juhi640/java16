package entity;

public class Actor {

	private int actorid;
	private String actorname;

	public Actor() {
		super();
	}

	public Actor(int actorid, String actorname) {
		super();
		this.actorid = actorid;
		this.actorname = actorname;
	}

	public int getActorid() {
		return actorid;
	}

	public void setActorid(int actorid) {
		this.actorid = actorid;
	}

	public String getActorname() {
		return actorname;
	}

	public void setActorname(String actorname) {
		this.actorname = actorname;
	}

}
