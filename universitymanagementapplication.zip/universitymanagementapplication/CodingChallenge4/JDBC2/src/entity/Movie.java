package entity;

public class Movie {

	private int movieid;
	private String moviename;

	public Movie() {
		super();
	}

	public Movie(int movieid, String moviename) {
		super();
		this.movieid = movieid;
		this.moviename = moviename;
	}

	public int getMovieid() {
		return movieid;
	}

	public void setMovieid(int movieid) {
		this.movieid = movieid;
	}

	public String getMoviename() {
		return moviename;
	}

	public void setMoviename(String moviename) {
		this.moviename = moviename;
	}

}
