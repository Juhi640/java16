package client;

import java.util.Scanner;

import entity.Actor;

public class App {
	
	static Scanner obj=new Scanner(System.in);
	
	public static Actor createActor() {
		
		Actor a=new Actor();
		System.out.println("enter actor id");
		int actorid = obj.nextInt();
		obj.nextLine();
		System.out.println("enter actor name");
		String actorname = obj.nextLine();
		a=new Actor(actorid,actorname);
		//return a;
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
